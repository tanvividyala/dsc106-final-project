# Handoff v3 · "Degrees of Consequence" — Time Jump autoplay + green palette

This bundle is a **focused update** on top of `design_handoff_v2_updates/`,
which itself builds on `design_handoff_climate_adventure/`. Two changes:

1. The **Time Jump sequence ("The future arrives")** now **autoplays**
   instead of being driven by scroll. It plays once when the section
   enters the viewport; the rest of the article does not exist on the
   page until the animation completes.
2. The accent color formerly known as **poppy** (a warm red, `#d85455`)
   has been **repainted green** (`#2d9c63`). The CSS variable *names*
   are intentionally preserved so consuming code does not need to be
   renamed.

> **What is NOT changing:** the Hero, Character Select, Calibration
> Overlay, Priorities scene, Metrics chapter (Temperature, CO₂, Sea
> level, Rainfall), "What could have been," and Outro — all carry
> forward exactly as documented in handoffs v1 and v2. Data, curves,
> SSP pathway mappings, dial geometry, and chart vizes are unchanged.

If you have the previous handoffs, read this for what's new and treat
the others as the source of truth for everything else.

---

## About the design files

The `source/` folder contains the **HTML prototype** of the live
experience — `index.html`, `styles.css`, and four React-via-Babel `.jsx`
files (`app.jsx`, `story.jsx`, `components.jsx`, `data.jsx`). These are
**design references**, not production code to ship. They show intended
look, motion, copy, and timing.

Your task is to **recreate this design in the target codebase's
environment** — whatever framework, component library, and styling
system that codebase already uses. If there is no existing codebase
yet, pick a sensible modern stack (React + Vite, Next.js, Svelte,
SolidJS — any of these are fine) and implement against the design
described below.

## Fidelity

**High-fidelity.** Colors, type, spacing, motion timings, and copy in
the source files are all final. Match them closely.

---

## At-a-glance changelog (v2 → v3)

| Area | Before (v2) | After (v3) |
| --- | --- | --- |
| **Time Jump driver** | Scroll-driven via a 280vh tall outer section + `position: sticky` inner that pinned to the viewport. Year, line, and tick ring all advanced with scroll progress. | **Auto-driven** via `requestAnimationFrame`. Section is 100vh, not sticky. A single play takes **8500 ms**, starting when the section enters the viewport (`rect.top < vh * 0.6 && rect.bottom > vh * 0.4`). After the animation finishes, a 900 ms hold reads the final beat, then the article unlocks. |
| **Progression gating** | Metrics Intro, the four Metric Blocks, "What could have been," and the Outro were rendered the moment a character was selected; the user could scroll past Time Jump at any speed. | The post-Time-Jump sections **do not mount** until Time Jump signals completion. On completion, the page smooth-scrolls to `[data-screen-label="05 Metrics Intro"]`. There is no way to skip the animation. |
| **Time Jump progress affordance** | None — progress was implied by scroll position. | A thin **horizontal progress bar** under the year ticker, `min(420px, 60vw)` × `2px`, fills left-to-right with the apricot accent. Linear `transition: width 120ms`. |
| **Accent palette** | `--poppy` was a warm red (`#d85455`). Used for the primary `--accent`, SSP-high pathway, Tycoon character, dial "inverted" arc color, lighthouse stripes, drought viz numerals & cracks, delta-worse text. | `--poppy` is now **forest green** (`#2d9c63`). All downstream usages flip automatically because they reference `var(--poppy-…)` rather than the literal hex. |
| **Tycoon portrait color** | `#b8403f` (matched old `--poppy-600`). | `#1f7045` (matches new `--poppy-600`). |
| **`theme-precip` metric-soft fill** | `rgba(216,84,85,0.10)` (literal pink rgb). | `rgba(45,156,99,0.10)` (matches new green). |

---

## 1 · Time Jump autoplay

### Behavior

1. The user finishes reading the Priorities scene and scrolls down.
2. Time Jump enters the viewport. Once **more than ~40% of the section
   is on screen** (`rect.top < window.innerHeight * 0.6 &&
   rect.bottom > window.innerHeight * 0.4`), the autoplay starts. It
   only starts once; subsequent scrolls do not restart it.
3. A single `requestAnimationFrame` loop drives a progress value `p`
   from 0 → 1 over **8500 ms** (linear).
4. The displayed year is `Math.round(2025 + 75 * eased)`, where
   `eased = 1 - (1 - clamp(p / 0.85, 0, 1))^1.6`. (Same easing as the
   v1 scroll-driven version — front-loaded so 2025 holds briefly and
   the final 15 % of the timeline hovers on 2100.)
5. Five narrative lines cross-fade in sequence (use `key={text}` on the
   text node so React unmounts/remounts and the `.fade-in` CSS
   animation re-runs):
   - `0.00 – 0.18` "The room empties. The decisions begin to settle."
   - `0.18 – 0.38` "A decade passes. Then another."
   - `0.38 – 0.62` "Children born during the meeting are now writing the headlines."
   - `0.62 – 0.84` "The atmosphere keeps a perfect ledger."
   - `0.84 – 1.01` "The future arrives. On schedule."
6. The radial tick marks (76 tick lines around a clock face) and the
   pointer line + dot draw out as the year advances — identical to v1,
   but now ticking automatically.
7. The new **progress bar** under the ticker fills from 0 % to 100 %
   tracking `p`.
8. When `p` reaches 1, a **900 ms hold** lets readers register
   "The future arrives. On schedule." Then `onComplete` fires.

### After onComplete

- The parent (`App`) flips `timeJumpDone` to `true`. This **conditionally
  renders** the rest of the article (Metrics Intro, four Metric Blocks,
  What Could Have Been, Outro). Until the flag flips, those nodes
  literally do not exist in the DOM — there is nothing below Time Jump
  to scroll into.
- After a 240 ms tick to allow layout, the page smooth-scrolls to
  `[data-screen-label="05 Metrics Intro"]`.
- "Restart" (Outro button) resets `timeJumpDone` to `false` along with
  the character selection, so the animation will play again if the
  user picks a new framework.

### Why this matters

The Time Jump is the article's "hand off the wheel" moment — the user
has chosen a framework and is now watching the consequences roll
forward. Tying it to scroll let some readers race through 2100 in under
a second; tying it to a fixed 8.5 s autoplay (plus a 900 ms beat hold)
guarantees every reader sits with the same passage of time before the
numbers arrive. The gating ensures the metrics chapter never appears
out of context.

### Don'ts

- **Do not** make the Time Jump scroll-driven or skippable in v3. The
  whole point of this revision is that it imposes a constant duration.
- **Do not** mount the post-Time-Jump sections eagerly. Even hiding
  them with CSS leaves them in the document and breaks the
  "auto-scroll to Metrics Intro" target calculation when the page
  reflows.
- **Do not** restart the animation on subsequent intersections. Use a
  `started` flag that latches.

### Implementation reference

- **`source/story.jsx`** — `TimeJump({ onComplete })` component. Look
  for the two `useEffect` hooks: one for the scroll-position trigger
  (with mount-time + resize fallbacks), one for the RAF loop.
- **`source/app.jsx`** — `App` component holds `timeJumpDone` state and
  the `handleTimeJumpComplete` handler. Conditional rendering of the
  post-Time-Jump sections lives here.
- **`source/styles.css`** — section `TIME JUMP` defines
  `.timejump-wrap` (now `height: 100vh`, not `280vh`), the
  no-longer-sticky `.timejump-sticky`, and the new
  `.timejump-progress` / `.timejump-progress-fill` rules.

---

## 2 · Pink → green palette swap

### Token changes

In `:root` in `styles.css`:

```css
/* Was a warm red ("poppy"). Repainted forest green per direction.
   Names retained so JS modules that reference them keep working. */
--poppy:     #2d9c63;
--poppy-600: #1f7045;
--poppy-500: #2d9c63;
--poppy-200: #b9deca;
```

Downstream tokens that resolve through `--poppy-*` flip automatically:

```
--accent       = var(--poppy-500)   /* primary action / link / brand */
--accent-hover = var(--poppy-600)
--accent-soft  = var(--poppy-200)
--ssp-high     = var(--poppy-500)   /* the "+4°C" pathway swatch */
```

### Places the new green now shows up

- Navbar brand "Consequence" italic
- Section eyebrows ("Chapter One · The framework", etc.)
- "Degrees of *Consequence*" hero italic
- Primary buttons ("Apply this framework", "Try a different framework")
- Selected character card border + soft outer glow
- Character card quip-cycler active dot, hover border
- Priorities scene: thought-progress active dot, panel eyebrow accent
- Dial arc when `inverted` is true (in `components.jsx`)
- SSP-high pathway swatch in `WhatCouldHaveBeen`
- "delta-worse" text in alt cards
- "Land in drought" big number + cracked-earth glyph in `PrecipViz`
- Lighthouse stripes in the SeaViz illustration
- `theme-precip` metric block's `--metric-soft` (used as a subtle wash
  behind the precip chart)

### The Tycoon character

The "Oil Tycoon" character was the v1/v2 anchor for the warm-red
identity. In v3 the character keeps the same name and copy but is now
visually anchored in green. Specifically:

- `data.jsx` → `CHARACTERS[0].accent` is still `'var(--poppy-500)'`,
  which now resolves to `#2d9c63`.
- `data.jsx` → `CHARACTERS[0].portraitColor` was updated from
  `'#b8403f'` to `'#1f7045'` so the avatar's literal fill matches the
  new `--poppy-600`.

Note: the **three character framework swatches are now `green / apricot
/ sage`** — all in the same warm/cool earthy family. If your codebase
has any explanatory legend or color key, update it accordingly.

### Things you do *not* need to do

- Do not rename `--poppy-*` to `--green-*`. The names are intentionally
  preserved so downstream rules and JSX `var(--poppy-…)` string
  references continue to work without a sweep.
- Do not introduce a separate `--green-*` family. There is only one
  "primary brand" hue. Earth-tone sage and moss remain as their own
  thing for SSP-low and chrome.

---

## 3 · Component contracts (v3 only)

### `<TimeJump onComplete={() => void} />`

| Prop | Type | Notes |
| --- | --- | --- |
| `onComplete` | `() => void` | Called once, after the RAF reaches `p = 1` plus a 900 ms hold. Parent should reveal the rest of the page in response. |

Internal state:

- `started: boolean` — latches `true` on first viewport entry. Never
  flips back.
- `p: number` — `[0, 1]` progress, updated each animation frame.

### `App` state additions

| State | Initial | Set by | Resets via |
| --- | --- | --- | --- |
| `timeJumpDone` | `false` | `handleTimeJumpComplete()` (also auto-scrolls to Metrics Intro 240 ms later) | `handleRestart()` |

---

## 4 · Design tokens (snapshot for v3)

Only the changed ones; everything else carries over from v2.

| Token | v2 value | v3 value |
| --- | --- | --- |
| `--poppy` | `#d85455` | `#2d9c63` |
| `--poppy-600` | `#b8403f` | `#1f7045` |
| `--poppy-500` | `#d85455` | `#2d9c63` |
| `--poppy-200` | `#f0b5b5` | `#b9deca` |
| `CHARACTERS[0].portraitColor` (Tycoon) | `#b8403f` | `#1f7045` |
| `theme-precip --metric-soft` | `rgba(216,84,85,0.10)` | `rgba(45,156,99,0.10)` |
| `.timejump-wrap { height }` | `280vh` | `100vh` |
| `.timejump-sticky { position }` | `sticky` | `relative` |

New:

```css
.timejump-progress {
  width: min(420px, 60vw);
  height: 2px;
  background: rgba(251,246,233,0.12);
  border-radius: var(--radius-pill);
  overflow: hidden;
  margin-top: var(--space-3);
}
.timejump-progress-fill {
  height: 100%;
  background: var(--apricot-500);
  box-shadow: 0 0 12px var(--apricot-500);
  transition: width 120ms linear;
}
```

---

## 5 · Files in this bundle

```
design_handoff_v3_autoplay_and_palette/
├── README.md            ← this document
└── source/
    ├── index.html       ← entry point; loads the four .jsx scripts via Babel
    ├── styles.css       ← full stylesheet, post-green-swap
    ├── app.jsx          ← App root + nav + section orchestration + gating
    ├── story.jsx        ← Hero, CharacterSelect, Priorities, Calibration,
    │                      TimeJump (NEW autoplay), Metrics, WhatCouldHaveBeen, Outro
    ├── components.jsx   ← Hooks, Globe, Portrait, Dial, charts, four metric vizes
    └── data.jsx         ← CHARACTERS, DIALS, SSP, METRIC_BEATS, summary tables
```

The .jsx files are not transpiled in the prototype — they run through
`@babel/standalone` in the browser. When recreating in a real codebase,
treat them as source for **logic and copy**, not for build pipeline
shape.

---

## 6 · Open questions / things worth confirming

- **Reduced-motion**: the autoplay is currently mandatory. For accessibility,
  consider honoring `prefers-reduced-motion: reduce` by either shortening
  the duration substantially or letting the user click through. Not in
  scope for this handoff, but flag it for triage.
- **Back / forward navigation**: if a user lands on the page via the
  browser back button after completing the experience once, the
  `timeJumpDone` flag is reset. That is intentional in the prototype
  but may want to be persisted via `sessionStorage` in production.
- **Replay**: there is currently no "replay this animation" affordance.
  The Outro's "Try a different framework" path is the only way to see
  it again. Confirm whether a dedicated replay button is desired.
