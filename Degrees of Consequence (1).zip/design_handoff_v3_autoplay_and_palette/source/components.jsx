// ============================================================
// components.jsx — shared atoms (portraits, globe, dials, viz)
// ============================================================

const { useEffect, useRef, useState, useMemo } = React;

// ---------- Hooks ----------------------------------------------------------

function useScrollProgress(ref) {
  const [p, setP] = useState(0);
  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    const onScroll = () => {
      const rect = node.getBoundingClientRect();
      const vh = window.innerHeight;
      const total = node.offsetHeight - vh;
      if (total <= 0) { setP(0); return; }
      const v = Math.max(0, Math.min(1, -rect.top / total));
      setP(v);
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
    return () => {
      window.removeEventListener('scroll', onScroll);
      window.removeEventListener('resize', onScroll);
    };
  }, [ref]);
  return p;
}

function useCycle(items, intervalMs = 2200, active = true) {
  const [i, setI] = useState(0);
  useEffect(() => {
    if (!active || !items || items.length < 2) return;
    const t = setInterval(() => setI(v => (v + 1) % items.length), intervalMs);
    return () => clearInterval(t);
  }, [items, intervalMs, active]);
  return [i, setI];
}

// ---------- Math helpers ---------------------------------------------------

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a, b, t) => a + (b - a) * t;

// Curve generator (would be replaced by real CMIP6 data lookup)
// metric ids: temp, co2, sea, precip
// ssp keys: LOW, MID, HIGH
function getMetricCurve(metric, ssp) {
  const targets = {
    temp:   { LOW: 1.8,  MID: 2.7,  HIGH: 4.4 },
    co2:    { LOW: 425,  MID: 540,  HIGH: 820 },
    sea:    { LOW: 60,   MID: 90,   HIGH: 160 },
    precip: { LOW: 4,    MID: 7,    HIGH: 12 },
  };
  const start2025 = { temp: 1.2, co2: 423, sea: 22, precip: 1.5 };
  const t2100 = targets[metric][ssp];
  const s = start2025[metric];
  const out = [];
  for (let y = 2025; y <= 2100; y++) {
    const x = (y - 2025) / 75;
    // ssp-shaped curves: LOW saturates, MID linear-ish, HIGH accelerates
    let f;
    if (ssp === 'LOW')  f = 1 - Math.pow(1 - x, 1.6);   // diminishing
    else if (ssp === 'MID') f = Math.pow(x, 1.0);
    else f = Math.pow(x, 1.45);                          // accelerating
    out.push({ year: y, val: s + (t2100 - s) * f });
  }
  return out;
}

// Historical series from 1900 → 2024, linearly interpolated between the
// anchor points defined in data.jsx. Returned shape matches getMetricCurve:
// [{year, val}].
function getMetricHistorical(metric) {
  const anchors = HISTORICAL_ANCHORS[metric];
  if (!anchors || anchors.length === 0) return [];
  const out = [];
  for (let y = anchors[0][0]; y < 2025; y++) {
    let i = 0;
    while (i < anchors.length - 1 && anchors[i + 1][0] <= y) i++;
    const [y1, v1] = anchors[i];
    const [y2, v2] = anchors[Math.min(i + 1, anchors.length - 1)];
    const t = y2 === y1 ? 0 : (y - y1) / (y2 - y1);
    out.push({ year: y, val: v1 + (v2 - v1) * t });
  }
  return out;
}

// ---------- Globe (halftone-dot earth, hero only) --------------------------

function Globe({ size = 600 }) {
  const dots = useMemo(() => {
    // fibonacci sphere
    const N = 720;
    const arr = [];
    const phi = Math.PI * (3 - Math.sqrt(5));
    for (let i = 0; i < N; i++) {
      const y = 1 - (i / (N - 1)) * 2;
      const r = Math.sqrt(1 - y * y);
      const theta = phi * i;
      arr.push({ x: Math.cos(theta) * r, y, z: Math.sin(theta) * r });
    }
    return arr;
  }, []);

  const [t, setT] = useState(0);
  useEffect(() => {
    let raf;
    let last = performance.now();
    const loop = (now) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      setT(v => v + dt * 0.18);
      raf = requestAnimationFrame(loop);
    };
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (!reduced) raf = requestAnimationFrame(loop);
    return () => raf && cancelAnimationFrame(raf);
  }, []);

  const cx = size / 2, cy = size / 2, R = size * 0.46;
  const cosT = Math.cos(t), sinT = Math.sin(t);
  const projected = dots.map(d => {
    // rotate around y
    const x = d.x * cosT + d.z * sinT;
    const z = -d.x * sinT + d.z * cosT;
    return { x: cx + x * R, y: cy + d.y * R, z };
  });

  return (
    <svg className="hero-globe" viewBox={`0 0 ${size} ${size}`} aria-hidden="true">
      <defs>
        <radialGradient id="g-glow" cx="50%" cy="45%" r="55%">
          <stop offset="0%" stopColor="#f1a97a" stopOpacity="0.25" />
          <stop offset="60%" stopColor="#f1a97a" stopOpacity="0.06" />
          <stop offset="100%" stopColor="#f1a97a" stopOpacity="0" />
        </radialGradient>
      </defs>
      <circle cx={cx} cy={cy} r={R * 1.18} fill="url(#g-glow)" />
      <circle cx={cx} cy={cy} r={R} fill="#fbf6e9" />
      {projected.map((p, i) => {
        const depth = (p.z + 1) / 2; // 0..1, front=1
        if (depth < 0.05) return null;
        const baseR = 1.3 + depth * 2.4;
        // continental "blobs" — use deterministic noise (sin combos) to pick filled cells
        const land = Math.sin(dots[i].x * 4.2 + 1) * Math.cos(dots[i].y * 3.1) + Math.sin(dots[i].z * 5.3) * 0.5;
        const isLand = land > 0.4;
        return (
          <circle
            key={i}
            cx={p.x}
            cy={p.y}
            r={isLand ? baseR * 1.1 : baseR * 0.55}
            fill={isLand ? '#60704e' : '#8a9776'}
            opacity={isLand ? 0.6 + depth * 0.35 : 0.18 + depth * 0.25}
          />
        );
      })}
    </svg>
  );
}

// ---------- Portrait (stylized SVG silhouette) -----------------------------

function Portrait({ id, color = '#60704e', size = 200 }) {
  // Three distinct, hand-tuned shapes. Cream background is supplied by parent.
  const accent = color;
  if (id === 'tycoon') {
    return (
      <svg viewBox="0 0 200 240" width={size} height={size}>
        {/* shoulders: power-suit jacket */}
        <path d="M10 240 L10 200 Q10 175 50 165 L75 158 L100 168 L125 158 L150 165 Q190 175 190 200 L190 240 Z"
          fill={accent} />
        {/* lapel notch */}
        <path d="M100 168 L88 200 L100 196 L112 200 Z" fill="#fbf6e9" opacity="0.85" />
        {/* pearl strand */}
        {[0,1,2,3,4,5,6,7].map(i => (
          <circle key={i} cx={68 + i*8} cy={185 + Math.sin(i*0.7)*2} r="2.6" fill="#fbf6e9" />
        ))}
        {/* neck */}
        <rect x="88" y="148" width="24" height="20" fill={accent} opacity="0.85" />
        {/* head */}
        <ellipse cx="100" cy="105" rx="42" ry="48" fill={accent} />
        {/* hair: tight bun */}
        <path d="M58 100 Q60 60 100 55 Q140 60 142 100 Q142 80 100 75 Q58 80 58 100 Z" fill="#2f3a26" />
        <circle cx="100" cy="58" r="14" fill="#2f3a26" />
      </svg>
    );
  }
  if (id === 'senator') {
    return (
      <svg viewBox="0 0 200 240" width={size} height={size}>
        {/* shoulders: suit */}
        <path d="M10 240 L10 200 Q10 175 48 162 L78 155 L100 168 L122 155 L152 162 Q190 175 190 200 L190 240 Z"
          fill={accent} />
        {/* shirt + tie */}
        <path d="M78 155 L100 168 L122 155 L122 240 L78 240 Z" fill="#fbf6e9" />
        <path d="M90 168 L110 168 L106 240 L94 240 Z" fill="#b8403f" />
        {/* neck */}
        <rect x="88" y="142" width="24" height="20" fill={accent} opacity="0.85" />
        {/* head */}
        <ellipse cx="100" cy="100" rx="40" ry="46" fill={accent} />
        {/* hair: side-part */}
        <path d="M60 92 Q62 56 100 52 Q138 56 140 92 Q138 70 110 68 Q90 70 80 80 Q70 90 60 92 Z" fill="#2f3a26" />
        {/* glasses */}
        <circle cx="86" cy="100" r="8" fill="none" stroke="#2f3a26" strokeWidth="2" />
        <circle cx="114" cy="100" r="8" fill="none" stroke="#2f3a26" strokeWidth="2" />
        <line x1="94" y1="100" x2="106" y2="100" stroke="#2f3a26" strokeWidth="2" />
      </svg>
    );
  }
  // scientist
  return (
    <svg viewBox="0 0 200 240" width={size} height={size}>
      {/* lab-coat-ish shoulders */}
      <path d="M10 240 L10 200 Q10 172 50 162 L80 158 L100 170 L120 158 L150 162 Q190 172 190 200 L190 240 Z"
        fill={accent} />
      {/* shirt collar */}
      <path d="M80 158 L100 170 L120 158 L114 180 L100 175 L86 180 Z" fill="#fbf6e9" />
      {/* neck */}
      <rect x="88" y="148" width="24" height="20" fill={accent} opacity="0.85" />
      {/* head */}
      <ellipse cx="100" cy="102" rx="42" ry="46" fill={accent} />
      {/* curly hair */}
      <g fill="#2f3a26">
        <circle cx="64" cy="80" r="14" />
        <circle cx="78" cy="62" r="14" />
        <circle cx="100" cy="56" r="15" />
        <circle cx="122" cy="62" r="14" />
        <circle cx="136" cy="80" r="14" />
        <circle cx="60" cy="100" r="10" />
        <circle cx="140" cy="100" r="10" />
      </g>
      {/* glasses */}
      <rect x="78" y="96" width="16" height="10" rx="2" fill="none" stroke="#2f3a26" strokeWidth="2" />
      <rect x="106" y="96" width="16" height="10" rx="2" fill="none" stroke="#2f3a26" strokeWidth="2" />
      <line x1="94" y1="101" x2="106" y2="101" stroke="#2f3a26" strokeWidth="2" />
    </svg>
  );
}

// ---------- Dial -----------------------------------------------------------

function Dial({ value, label, subtitle, active, inverted, wobbling }) {
  // value 0..100 → angle -135° (left) to +135° (right)
  const angle = -135 + (value / 100) * 270;
  const trans = wobbling
    ? 'all 160ms cubic-bezier(0.34, 1.56, 0.64, 1)'
    : 'all 1.1s cubic-bezier(0.34, 1.56, 0.64, 1)';
  const needleTrans = wobbling
    ? 'transform 160ms cubic-bezier(0.34, 1.56, 0.64, 1)'
    : 'transform 1.1s cubic-bezier(0.34, 1.56, 0.64, 1)';
  const r = 48;
  // arc from -135deg to value angle
  const startRad = (-135 - 90) * Math.PI / 180;
  const endRad = (angle - 90) * Math.PI / 180;
  const ax = 64 + r * Math.cos(startRad);
  const ay = 64 + r * Math.sin(startRad);
  const bx = 64 + r * Math.cos(endRad);
  const by = 64 + r * Math.sin(endRad);
  const large = (angle - (-135)) > 180 ? 1 : 0;
  const arcColor = inverted ? 'var(--poppy-500)' : 'var(--apricot-500)';
  return (
    <div className={`dial ${active ? 'active' : ''}`}>
      <svg className="dial-svg" viewBox="0 0 128 128">
        {/* tick marks */}
        {Array.from({ length: 11 }).map((_, i) => {
          const a = (-135 + (i / 10) * 270) * Math.PI / 180;
          const cx = 64 + Math.cos(a - Math.PI/2) * 56;
          const cy = 64 + Math.sin(a - Math.PI/2) * 56;
          const cx2 = 64 + Math.cos(a - Math.PI/2) * 60;
          const cy2 = 64 + Math.sin(a - Math.PI/2) * 60;
          return <line key={i} x1={cx} y1={cy} x2={cx2} y2={cy2} stroke="rgba(251,246,233,0.25)" strokeWidth="1" />;
        })}
        {/* track */}
        <path
          d={`M ${64 + r * Math.cos((-135-90)*Math.PI/180)} ${64 + r * Math.sin((-135-90)*Math.PI/180)}
              A ${r} ${r} 0 1 1 ${64 + r * Math.cos((135-90)*Math.PI/180)} ${64 + r * Math.sin((135-90)*Math.PI/180)}`}
          fill="none" stroke="rgba(251,246,233,0.10)" strokeWidth="6" strokeLinecap="round"
        />
        {/* active arc */}
        {value > 1 && (
          <path
            d={`M ${ax} ${ay} A ${r} ${r} 0 ${large} 1 ${bx} ${by}`}
            fill="none" stroke={arcColor} strokeWidth="6" strokeLinecap="round"
            style={{ transition: trans }}
          />
        )}
        {/* knob face */}
        <circle cx="64" cy="64" r="34" fill="#1f2818" stroke="rgba(251,246,233,0.08)" />
        {/* needle */}
        <g style={{ transform: `rotate(${angle}deg)`, transformOrigin: '64px 64px', transition: needleTrans }}>
          <line x1="64" y1="64" x2="64" y2="34" stroke={arcColor} strokeWidth="3" strokeLinecap="round" />
          <circle cx="64" cy="64" r="5" fill="#1f2818" stroke={arcColor} strokeWidth="2" />
        </g>
      </svg>
      <div className="dial-label">{label}</div>
      <div className="dial-value">{value} / 100</div>
    </div>
  );
}

// ---------- Time-series chart -----------------------------------------------
// Replaces the old single-line sparkline. Renders historical (1900-2024) +
// projected (2025-2100) data with proper x/y axes so the reader can see the
// gravity of the recent acceleration relative to a century of context.
//
// Props:
//   historical   [{year, val}]   1900 → 2024 (or whatever range exists)
//   projected    [{year, val}]   2025 → 2100
//   currentYear  number          year of the scroll-driven marker
//   accent       css color       primary line + marker color
//   muted        css color       historical line + axis ticks
//   yTicks       number[]        values to label on the y-axis
//   xTicks       number[]        years to label on the x-axis
//   formatY      (v) => string   label formatter for y ticks AND the readout
//   pad          {t,r,b,l}       chart padding inside the SVG
//   height       number          rendered height in px (used for viewBox h)
function TimeSeriesChart({
  historical, projected, currentYear,
  accent = 'currentColor', muted = 'currentColor',
  yTicks, xTicks, formatY = (v) => `${v}`,
  pad = { t: 14, r: 16, b: 28, l: 44 },
  width = 800, height = 220,
}) {
  const all = [...historical, ...projected];
  const ys = all.map(d => d.val);
  const yMin = Math.min(yTicks?.[0] ?? Infinity, ...ys);
  const yMax = Math.max(yTicks?.[yTicks.length - 1] ?? -Infinity, ...ys);
  const xMin = all[0].year;
  const xMax = all[all.length - 1].year;

  const W = width, H = height;
  const innerW = W - pad.l - pad.r;
  const innerH = H - pad.t - pad.b;

  const sx = (year) => pad.l + ((year - xMin) / (xMax - xMin)) * innerW;
  const sy = (val)  => pad.t + (1 - (val - yMin) / (yMax - yMin || 1)) * innerH;

  const histPath = historical.map((d, i) => `${i === 0 ? 'M' : 'L'} ${sx(d.year).toFixed(2)} ${sy(d.val).toFixed(2)}`).join(' ');
  // Bridge the historical→projected line at 2025 so there's no visual gap.
  const projSeries = historical.length
    ? [historical[historical.length - 1], ...projected]
    : projected;
  const projPath = projSeries.map((d, i) => `${i === 0 ? 'M' : 'L'} ${sx(d.year).toFixed(2)} ${sy(d.val).toFixed(2)}`).join(' ');

  // Filled area under the projected line, only — emphasizes the rise.
  const fillPath = `${projPath} L ${sx(projSeries[projSeries.length - 1].year)} ${sy(yMin)} L ${sx(projSeries[0].year)} ${sy(yMin)} Z`;

  // Current marker
  const cy = clamp(currentYear, xMin, xMax);
  const valNow = (() => {
    if (cy <= 2024) {
      const i = clamp(cy - historical[0].year, 0, historical.length - 1);
      return historical[i].val;
    }
    const i = clamp(cy - 2025, 0, projected.length - 1);
    return projected[i].val;
  })();
  const cxPx = sx(cy);
  const cyPx = sy(valNow);

  const splitX = sx(2025);

  return (
    <svg className="tsc" viewBox={`0 0 ${W} ${H}`}>
      {/* y-axis gridlines + labels */}
      {yTicks && yTicks.map((v, i) => {
        const y = sy(v);
        return (
          <g key={`y${i}`} className="tsc-grid">
            <line x1={pad.l} x2={W - pad.r} y1={y} y2={y}
              stroke={muted} strokeOpacity="0.18" strokeWidth="1" strokeDasharray="2 4" />
            <text x={pad.l - 8} y={y + 3} textAnchor="end"
              fontFamily="DM Mono, monospace" fontSize="10" letterSpacing="1.5"
              fill={muted} opacity="0.8">
              {formatY(v)}
            </text>
          </g>
        );
      })}

      {/* x-axis baseline */}
      <line x1={pad.l} x2={W - pad.r} y1={H - pad.b} y2={H - pad.b}
        stroke={muted} strokeOpacity="0.35" strokeWidth="1" />

      {/* x-axis ticks + year labels */}
      {xTicks && xTicks.map((y, i) => {
        const x = sx(y);
        return (
          <g key={`x${i}`}>
            <line x1={x} x2={x} y1={H - pad.b} y2={H - pad.b + 4}
              stroke={muted} strokeOpacity="0.5" />
            <text x={x} y={H - pad.b + 16} textAnchor="middle"
              fontFamily="DM Mono, monospace" fontSize="10" letterSpacing="1.5"
              fill={muted} opacity="0.85">
              {y}
            </text>
          </g>
        );
      })}

      {/* split line at 2025 — separates record from projection */}
      <line x1={splitX} x2={splitX} y1={pad.t} y2={H - pad.b}
        stroke={muted} strokeOpacity="0.45" strokeWidth="1" strokeDasharray="3 3" />
      <text x={splitX + 4} y={pad.t + 10}
        fontFamily="DM Mono, monospace" fontSize="9" letterSpacing="2"
        fill={muted} opacity="0.7">
        2025 · PROJECTION
      </text>

      {/* filled area under projection */}
      <path d={fillPath} fill={accent} opacity="0.10" />

      {/* historical line */}
      <path d={histPath} fill="none" stroke={muted} strokeWidth="1.5" opacity="0.55"
        strokeLinecap="round" strokeLinejoin="round" />

      {/* projected line */}
      <path d={projPath} fill="none" stroke={accent} strokeWidth="2"
        strokeLinecap="round" strokeLinejoin="round" />

      {/* current-year marker */}
      <line x1={cxPx} x2={cxPx} y1={pad.t} y2={H - pad.b}
        stroke={accent} strokeWidth="1" strokeDasharray="2 3" opacity="0.7" />
      <circle cx={cxPx} cy={cyPx} r="4" fill={accent} />
      <circle cx={cxPx} cy={cyPx} r="7" fill="none" stroke={accent} strokeOpacity="0.4" />
    </svg>
  );
}

// Legacy export kept for compatibility — same signature, internally uses the
// new chart for a single-line series without axes.
function MiniLine({ data, accent = 'currentColor', currentYear }) {
  return (
    <TimeSeriesChart
      historical={[]}
      projected={data}
      currentYear={currentYear}
      accent={accent}
      muted={accent}
      xTicks={null}
      yTicks={null}
      pad={{ t: 4, r: 4, b: 4, l: 4 }}
      height={56}
    />
  );
}

// ---------- Metric vizes ---------------------------------------------------

function TempViz({ year, value }) {
  // value: temp anomaly in °C
  // central orb that warms cooler -> hotter; ring of 76 ticks 2025-2100
  const t = clamp(value / 5, 0, 1); // 0..1 over 0-5°C
  const orbColor = `oklch(${75 - t*22}% ${0.10 + t*0.16} ${65 - t*40})`;
  const ticks = 76;
  const filled = clamp(year - 2025 + 1, 0, ticks);
  return (
    <svg viewBox="0 0 400 400">
      <defs>
        <radialGradient id="orb-g" cx="40%" cy="40%" r="60%">
          <stop offset="0%" stopColor="#fbf6e9" stopOpacity="0.5" />
          <stop offset="100%" stopColor={orbColor} stopOpacity="1" />
        </radialGradient>
      </defs>
      {/* year ring */}
      {Array.from({ length: ticks }).map((_, i) => {
        const a = (-90 + (i / ticks) * 360) * Math.PI / 180;
        const r1 = 175, r2 = 192;
        const x1 = 200 + Math.cos(a) * r1;
        const y1 = 200 + Math.sin(a) * r1;
        const x2 = 200 + Math.cos(a) * r2;
        const y2 = 200 + Math.sin(a) * r2;
        return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2}
          stroke={i < filled ? 'var(--apricot-500)' : 'rgba(251,246,233,0.18)'}
          strokeWidth={i < filled ? 2 : 1} />;
      })}
      {/* orb */}
      <circle cx="200" cy="200" r="135" fill={orbColor} opacity="0.92" />
      <circle cx="200" cy="200" r="135" fill="url(#orb-g)" />
      {/* center label */}
      <text x="200" y="195" textAnchor="middle" fontFamily="Cooper Md BT, serif" fontSize="92" fill="#fbf6e9">+{value.toFixed(1)}</text>
      <text x="200" y="232" textAnchor="middle" fontFamily="DM Mono, monospace" fontSize="13" letterSpacing="3" fill="#fbf6e9" opacity="0.7">°C ANOMALY</text>
    </svg>
  );
}

function CO2Viz({ year, value }) {
  // 30x30 grid (900 cells). 280 ppm baseline = 280/900 fill = ~310 cells (scaled).
  // Use mapping: 280 ppm → 280 cells filled muted; current value → cells filled accent.
  const cells = 30 * 30;
  const baseline = Math.round((280 / 1000) * cells);  // ~252
  const total    = clamp(Math.round((value / 1000) * cells), 0, cells);
  return (
    <svg viewBox="0 0 400 400">
      {Array.from({ length: cells }).map((_, i) => {
        const x = (i % 30) * 13 + 8;
        const y = Math.floor(i / 30) * 13 + 12;
        let fill = 'rgba(47,58,38,0.08)';
        if (i < baseline) fill = 'rgba(47,58,38,0.32)';
        if (i < total)    fill = 'var(--moss-900)';
        return <circle key={i} cx={x} cy={y} r="3.2" fill={fill} />;
      })}
      <text x="8" y="408" fontFamily="DM Mono, monospace" fontSize="11" letterSpacing="2" fill="#2f3a26" opacity="0.7">280 PPM · 1850 BASELINE</text>
      <text x="400" y="408" textAnchor="end" fontFamily="DM Mono, monospace" fontSize="11" letterSpacing="2" fill="#2f3a26">{Math.round(value)} PPM · {year}</text>
    </svg>
  );
}

function SeaViz({ year, value }) {
  // value: cm above 2025 baseline. Render as side-view scene with rising water.
  const v = clamp(value, 0, 200);
  const baselineY = 290;          // beach / sea level baseline
  const lowCliffY = 250;          // headland top (left)
  const highCliffY = 210;         // promontory top (right) — lighthouse sits here
  const waterY = baselineY - v * 0.7; // px

  // Lighthouse geometry — base ON the high cliff at y=highCliffY
  const lhX = 305;                // tower center
  const lhTowerW = 16;
  const lhTowerTop = highCliffY - 64;  // 146
  const lhRoomY   = lhTowerTop - 14;   // 132
  const lhRoomW   = 24;
  const lhRoofTop = lhRoomY - 14;      // 118

  // Building on the low cliff — base ON the cliff at y=lowCliffY
  const bldX = 132, bldW = 36, bldTop = lowCliffY - 60; // 190

  return (
    <svg viewBox="0 0 400 400">
      {/* coast silhouette: flat beach + two raised areas */}
      <path d={`M0 ${baselineY}
                L100 ${baselineY}
                L108 ${lowCliffY} L180 ${lowCliffY} L188 ${baselineY}
                L260 ${baselineY}
                L270 ${highCliffY} L348 ${highCliffY} L356 ${baselineY}
                L400 ${baselineY} L400 400 L0 400 Z`}
        fill="rgba(145,173,148,0.28)" />

      {/* Building on low cliff */}
      <rect x={bldX} y={bldTop} width={bldW} height={lowCliffY - bldTop} fill="rgba(251,246,233,0.7)" />
      {/* roof */}
      <polygon points={`${bldX - 2},${bldTop} ${bldX + bldW + 2},${bldTop} ${bldX + bldW / 2},${bldTop - 10}`}
        fill="rgba(47,58,38,0.55)" />
      {/* windows */}
      {[0, 1, 2].map(r => [0, 1, 2].map(c => (
        <rect key={`${r}${c}`} x={bldX + 4 + c * 10} y={bldTop + 8 + r * 16} width="6" height="9" fill="rgba(47,58,38,0.6)" />
      )))}

      {/* Lighthouse on high cliff */}
      {/* tower */}
      <rect x={lhX - lhTowerW / 2} y={lhTowerTop}
        width={lhTowerW} height={highCliffY - lhTowerTop}
        fill="rgba(251,246,233,0.95)" />
      {/* red stripes on tower */}
      <rect x={lhX - lhTowerW / 2} y={lhTowerTop + 16} width={lhTowerW} height="6" fill="var(--poppy-500)" />
      <rect x={lhX - lhTowerW / 2} y={lhTowerTop + 40} width={lhTowerW} height="6" fill="var(--poppy-500)" />
      {/* gallery/balcony */}
      <rect x={lhX - lhRoomW / 2 - 1} y={lhRoomY + 12} width={lhRoomW + 2} height="3" fill="rgba(47,58,38,0.85)" />
      {/* light room */}
      <rect x={lhX - lhRoomW / 2} y={lhRoomY} width={lhRoomW} height="12" fill="rgba(241,169,122,0.95)" />
      <rect x={lhX - lhRoomW / 2} y={lhRoomY} width={lhRoomW} height="12" fill="none" stroke="rgba(47,58,38,0.7)" strokeWidth="1" />
      {/* roof */}
      <polygon points={`${lhX - lhRoomW / 2 - 1},${lhRoomY} ${lhX + lhRoomW / 2 + 1},${lhRoomY} ${lhX},${lhRoofTop}`}
        fill="var(--moss-900)" />
      {/* finial */}
      <line x1={lhX} y1={lhRoofTop} x2={lhX} y2={lhRoofTop - 6} stroke="var(--moss-900)" strokeWidth="1.5" />
      <circle cx={lhX} cy={lhRoofTop - 7} r="1.5" fill="var(--moss-900)" />
      {/* baseline dashed */}
      <line x1="0" y1={baselineY} x2="400" y2={baselineY} stroke="rgba(251,246,233,0.5)" strokeWidth="1" strokeDasharray="4 4" />
      <text x="8" y={baselineY - 8} fontFamily="DM Mono, monospace" fontSize="10" letterSpacing="2" fill="rgba(251,246,233,0.65)">2025 SEA LEVEL</text>
      {/* water */}
      <rect x="0" y={waterY} width="400" height={400 - waterY} fill="var(--sage-500)" opacity="0.85" />
      {/* wave detail */}
      <path d={`M0 ${waterY} Q 50 ${waterY - 4} 100 ${waterY} T 200 ${waterY} T 300 ${waterY} T 400 ${waterY} L 400 ${waterY + 6} L 0 ${waterY + 6} Z`}
        fill="rgba(251,246,233,0.18)" />
      {/* scale */}
      <line x1="380" y1={baselineY - 200 * 0.7} x2="380" y2={baselineY} stroke="rgba(251,246,233,0.5)" />
      {[0,50,100,150,200].map(cm => {
        const y = baselineY - cm * 0.7;
        return (
          <g key={cm}>
            <line x1="376" y1={y} x2="380" y2={y} stroke="rgba(251,246,233,0.65)" />
            <text x="372" y={y + 3} textAnchor="end" fontFamily="DM Mono, monospace" fontSize="10" fill="rgba(251,246,233,0.7)">{cm}cm</text>
          </g>
        );
      })}
      {/* big value */}
      <text x="200" y="60" textAnchor="middle" fontFamily="Cooper Md BT, serif" fontSize="68" fill="#fbf6e9">+{Math.round(value)}cm</text>
      <text x="200" y="90" textAnchor="middle" fontFamily="DM Mono, monospace" fontSize="11" letterSpacing="3" fill="#fbf6e9" opacity="0.7">ABOVE 2025</text>
    </svg>
  );
}

function PrecipViz({ year, value }) {
  // value: % change in extreme precip + drought share (combined index)
  const droughtShare = clamp(value * 2.5, 0, 60); // %
  const rainDays = Math.round(15 + value * 2.5);
  return (
    <svg viewBox="0 0 400 400">
      {/* DROUGHT panel */}
      <rect x="0" y="0" width="400" height="195" rx="14" fill="rgba(47,58,38,0.05)" />
      <text x="16" y="32" fontFamily="DM Mono, monospace" fontSize="11" letterSpacing="3" fill="#2f3a26" opacity="0.75">LAND IN DROUGHT</text>
      <text x="16" y="92" fontFamily="Cooper Md BT, serif" fontSize="72" fill="var(--poppy-500)">{Math.round(droughtShare)}%</text>
      {/* cracked-earth glyph */}
      <g transform="translate(220,40)" stroke="var(--poppy-500)" strokeWidth="2" fill="none" opacity="0.65">
        <path d="M0 80 L40 60 L75 80 L110 65 L150 80" />
        <path d="M0 110 L40 100 L75 115 L110 100 L150 115" />
        <path d="M30 60 L40 100" />
        <path d="M75 80 L75 115" />
        <path d="M110 65 L110 100" />
        <path d="M0 140 L40 130 L75 145 L110 130 L150 145" />
      </g>
      {/* RAIN panel */}
      <rect x="0" y="205" width="400" height="195" rx="14" fill="rgba(47,58,38,0.05)" />
      <text x="16" y="237" fontFamily="DM Mono, monospace" fontSize="11" letterSpacing="3" fill="#2f3a26" opacity="0.75">EXTREME RAIN DAYS / YR</text>
      <text x="16" y="297" fontFamily="Cooper Md BT, serif" fontSize="72" fill="var(--moss-900)">{rainDays}</text>
      {/* rain lines whose density scales with value */}
      <g stroke="var(--moss-900)" strokeWidth="1.4" opacity="0.55">
        {Array.from({ length: clamp(Math.round(8 + value * 1.6), 8, 36) }).map((_, i) => {
          const x = 220 + (i * 11) % 160;
          const yOff = (i * 17) % 100;
          return <line key={i} x1={x} y1={220 + yOff} x2={x - 6} y2={244 + yOff} />;
        })}
      </g>
      {/* footer */}
      <text x="200" y="395" textAnchor="middle" fontFamily="DM Mono, monospace" fontSize="11" letterSpacing="3" fill="#2f3a26" opacity="0.55">{year} · vs 2025</text>
    </svg>
  );
}

const METRIC_VIZ = { temp: TempViz, co2: CO2Viz, sea: SeaViz, precip: PrecipViz };

// ---------- Arrow icon -----------------------------------------------------

function ArrowRight() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <line x1="5" y1="12" x2="19" y2="12" />
      <polyline points="13 6 19 12 13 18" />
    </svg>
  );
}
function ArrowDown() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <line x1="12" y1="5" x2="12" y2="19" />
      <polyline points="6 13 12 19 18 13" />
    </svg>
  );
}
function RestartIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 12a9 9 0 1 0 3-6.7L3 8" />
      <polyline points="3 3 3 8 8 8" />
    </svg>
  );
}

Object.assign(window, {
  useScrollProgress, useCycle, clamp, lerp, getMetricCurve, getMetricHistorical,
  Globe, Portrait, Dial, MiniLine, TimeSeriesChart,
  TempViz, CO2Viz, SeaViz, PrecipViz, METRIC_VIZ,
  ArrowRight, ArrowDown, RestartIcon,
});
