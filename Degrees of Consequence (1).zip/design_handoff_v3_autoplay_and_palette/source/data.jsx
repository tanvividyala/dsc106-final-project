// ============================================================
// data.jsx — characters, scenarios, narrative beats
// ============================================================

const SSP = {
  LOW:  { code: 'SSP1-2.6', name: 'A Sustainable World',     warming: 1.8, color: 'var(--ssp-low)',  shortName: 'Sustainable' },
  MID:  { code: 'SSP2-4.5', name: 'Middle of the Road',      warming: 2.7, color: 'var(--ssp-mid)',  shortName: 'Middle Road' },
  HIGH: { code: 'SSP5-8.5', name: 'Fossil-Fueled Development',warming: 4.4, color: 'var(--ssp-high)', shortName: 'Fossil-Fueled' },
};

// Six priority dials, in the order the character "thinks" about them.
const DIALS = [
  { id: 'fossil',  label: 'Fossil fuel',     subtitle: 'Investment in oil, gas, coal',  inverted: true,
    definition: 'How heavily the framework keeps investing in extracting and burning oil, gas, and coal.' },
  { id: 'renew',   label: 'Renewables',      subtitle: 'Solar, wind, grid buildout',    inverted: false,
    definition: 'How fast solar, wind, and a modernized electric grid are scaled up to replace fossil power.' },
  { id: 'carbon',  label: 'Carbon pricing',  subtitle: 'Tax, cap-and-trade',            inverted: false,
    definition: 'A policy that puts a price on every ton of CO\u2082 emitted \u2014 via a carbon tax or a cap\u2011and\u2011trade market \u2014 so polluters pay the climate cost instead of passing it to everyone else.' },
  { id: 'forest',  label: 'Forests & land',  subtitle: 'Protection, restoration',       inverted: false,
    definition: 'How aggressively existing forests and soils are protected, and degraded land is restored so it keeps absorbing carbon.' },
  { id: 'coop',    label: 'Cooperation',     subtitle: 'International agreements',      inverted: false,
    definition: 'How seriously countries honor binding international agreements and share finance and technology with one another.' },
  { id: 'consume', label: 'Consumption',     subtitle: 'Demand-side reduction',         inverted: false,
    definition: 'How much the framework reduces demand itself \u2014 less driving, flying, meat, and material waste \u2014 instead of only swapping the supply.' },
];

// Characters — each has a portrait, quips (hover/idle cycle), preset dial values,
// and a "thought" per dial that plays in the priorities scene.
const CHARACTERS = [
  {
    id: 'tycoon',
    tag: 'Framework One',
    name: 'The Oil Tycoon',
    role: 'Energy · extraction · growth',
    accent: 'var(--poppy-500)',
    ssp: 'HIGH',
    portraitColor: '#1f7045',
    quips: [
      'Treats fossil fuels as the foundation of modern prosperity.',
      'Frames climate action primarily as an economic threat.',
      'Trusts the market to surface the right energy mix when ready.',
      'Sees regulation as a brake on growth, not a tool for steering it.',
    ],
    dials: { fossil: 95, renew: 25, carbon: 8, forest: 18, coop: 22, consume: 12 },
    thoughts: {
      fossil:  'In this framework, oil and gas are not optional — they are civilization\'s scaffolding. Expansion continues, and any phase-out is treated as a problem for a later decade.',
      renew:   'Renewables are tolerated as a public-relations gesture. Investment stays modest; subsidies are framed as someone else\'s budget line.',
      carbon:  'A price on carbon reads as a tax on prosperity. The default position is to oppose, dilute, or carve out exemptions until the proposal collapses.',
      forest:  'Land protection competes with extraction rights. When the two collide, extraction tends to win.',
      coop:    'International climate accords are signed for the photo, then weakened in implementation. Domestic priorities outrank treaty obligations.',
      consume: 'Asking citizens to consume less reads as politically untenable. Demand-side policy is left off the table.',
    },
  },
  {
    id: 'senator',
    tag: 'Framework Two',
    name: 'The Legislator',
    role: 'Coalition · compromise · cycle',
    accent: 'var(--apricot-500)',
    ssp: 'MID',
    portraitColor: '#d98453',
    quips: [
      'Treats climate policy as a calendar problem — delay where possible, signal urgency where required.',
      'Balances donor interests against polling, and polling against the next election cycle.',
      'Prefers symbolic action over structural change; ribbon-cuttings over restructuring.',
      'Reads every climate proposal first through the lens of energy-producing districts.',
    ],
    dials: { fossil: 55, renew: 52, carbon: 35, forest: 48, coop: 50, consume: 30 },
    thoughts: {
      fossil:  'A managed taper, not a hard turn-off. Existing producers are protected; transition timelines stretch across multiple election cycles.',
      renew:   'Renewables are funded, modestly, with announcements out-pacing deployment. Buildout is steady but never fast enough to displace incumbents.',
      carbon:  'A small fee, phased in over a decade, with generous exemptions for energy-intensive industry and politically sensitive constituencies.',
      forest:  'Conservation is popular and well-suited to press releases. Funding is announced; enforcement receives less attention.',
      coop:    'International agreements are signed and celebrated; binding measures are softened in the fine print.',
      consume: 'Demand-side change is left to voluntary action. Mandates would alienate too many voters to clear the floor.',
    },
  },
  {
    id: 'scientist',
    tag: 'Framework Three',
    name: 'The Climate Scientist',
    role: 'Pathway · projection · evidence',
    accent: 'var(--sage-500)',
    ssp: 'LOW',
    portraitColor: '#6f8c73',
    quips: [
      'Treats the IPCC pathway as the floor of ambition, not the ceiling.',
      'Anchors every recommendation in observed data and ensemble projections.',
      'Frames the cost of inaction as cumulative, compounding, and already underway.',
      'Argues that the cheapest decade to act is always the current one.',
    ],
    dials: { fossil: 10, renew: 92, carbon: 85, forest: 78, coop: 88, consume: 68 },
    thoughts: {
      fossil:  'New extraction halts this decade. Existing wells phase out on a schedule the IEA has already drawn. There is no pathway to 1.5°C that includes new oil.',
      renew:   'Renewable capacity triples by 2030. The technology exists; the financing exists; the binding constraint is permitting and political will.',
      carbon:  'A binding carbon price, harmonized internationally, set well north of $150 per ton. It accomplishes in a year what subsidies do in fifteen.',
      forest:  'Primary forest is protected as critical infrastructure. Degraded land is restored at scale. Carbon sinks are treated as non-negotiable.',
      coop:    'The Global South is brought to the table as a financing partner, not a recipient. Leadership is loud; financing is generous.',
      consume: 'Demand-side reduction targets the top decile of emitters — wealthy households in wealthy countries — where impact per intervention is highest.',
    },
  },
];

// Narrative beats by metric × SSP, keyed to milestone years.
// Component picks the latest beat whose year <= current year.
const METRIC_BEATS = {
  temp: {
    LOW: [
      { year: 2025, headline: 'Hotter, but not yet broken.', body: 'The 1.5°C threshold flickers above and below the line. Heatwaves arrive earlier, longer. The decade ends with the first global price on carbon.' },
      { year: 2050, headline: 'A plateau, hard-won.', body: 'Global emissions peaked in the late 2030s and have been falling for a decade. The thermometer settles near +1.7°C. The world is still warmer than any human lived in until 2024.' },
      { year: 2080, headline: 'A ceiling that holds.', body: 'Temperatures level off near +1.8°C. The Arctic still loses ice every summer, but the Atlantic circulation persists. The bet — that we acted in time — has mostly paid out.' },
    ],
    MID: [
      { year: 2025, headline: 'The curve refuses to bend.', body: 'Pledges stack on pledges. Emissions are flat. Each summer is the hottest on record — and remains so for less than a year.' },
      { year: 2050, headline: 'A different climate, openly.', body: 'The world is +2.0°C warmer. Wet-bulb events hit the Gulf, the Persian Gulf, and South Asia each summer. The cooling industry doubles.' },
      { year: 2080, headline: 'Past the guardrails.', body: 'Temperatures cross +2.5°C and keep climbing. The IPCC publishes its first "irreversible loss" volume. Insurers exit entire ZIP codes.' },
    ],
    HIGH: [
      { year: 2025, headline: 'The thermometer goes vertical.', body: 'No abatement. Each summer eclipses the last by a margin that used to define a decade. Records aren\'t broken — they\'re lapped.' },
      { year: 2050, headline: 'A planet rewriting itself.', body: 'At +3.0°C, the Amazon transitions from rainforest to savanna. Greenland\'s melt accelerates past the models. The first billion-person heat event hits South Asia.' },
      { year: 2080, headline: 'Off the chart we drew in 2024.', body: 'The system passes +4°C. The conversation moves from mitigation to triage. Climate is no longer a beat — it is the whole front page.' },
    ],
  },
  co2: {
    LOW:  [
      { year: 2025, headline: 'The peak, in sight.', body: 'Atmospheric CO₂ sits at 423 ppm — the highest in 4 million years. The annual rate of increase finally slows.' },
      { year: 2050, headline: 'Past the maximum.', body: 'CO₂ peaks near 445 ppm, then begins, slowly, to fall. Direct-air capture comes online at scale. The plants take back some of what we gave them.' },
      { year: 2080, headline: 'Falling, still high.', body: 'Concentrations drop below 430 ppm. Still higher than any moment in human history before 2014 — but pointed in the right direction.' },
    ],
    MID:  [
      { year: 2025, headline: 'Numbers we used to argue about.', body: 'CO₂ at 423 ppm. The number stops being controversial; the controversy moves to who pays.' },
      { year: 2050, headline: '500 ppm, give or take.', body: 'Concentrations cross 500 ppm. Pliocene levels — the last time, sea level was 25 meters higher.' },
      { year: 2080, headline: 'Still rising, slower.', body: 'CO₂ flirts with 550 ppm. The curve bends, eventually, but not before the next generation inherits the bill.' },
    ],
    HIGH: [
      { year: 2025, headline: 'The exponential continues.', body: 'CO₂ at 423 ppm and accelerating. Coal, gas, and oil all set new annual records.' },
      { year: 2050, headline: 'Past 550, into uncharted air.', body: 'Concentrations cross 550 ppm. The last time the atmosphere held this much carbon, palm trees grew in Wyoming.' },
      { year: 2080, headline: '800 ppm and counting.', body: 'The atmosphere holds more CO₂ than at any point since the Eocene. Models stop reporting upper bounds — there are none.' },
    ],
  },
  sea: {
    LOW: [
      { year: 2025, headline: 'A few centimeters, mostly Greenland.', body: 'The sea is 22 cm higher than it was when your grandparents were born. King tides reach further inland each fall.' },
      { year: 2050, headline: 'A line on a wall.', body: 'Forty centimeters of rise. Miami spends a generation on pumps and seawalls. Jakarta moves its capital. Most other coastal cities figure it out.' },
      { year: 2080, headline: 'Slower than feared.', body: 'Around 60 cm by 2100. Greenland stabilizes. Antarctica holds. We bought time the only way time can be bought — by doing the work.' },
    ],
    MID: [
      { year: 2025, headline: 'The water is patient.', body: 'Rise of ~22 cm. Most coastal flooding still feels exceptional. The word "nuisance" begins to lose its meaning.' },
      { year: 2050, headline: 'A meter on the long forecast.', body: 'Sea rises 55 cm. The IPCC quietly retires the optimistic projections. Real estate north of the floodline becomes a category.' },
      { year: 2080, headline: 'Coastlines redrawn.', body: 'Approaching 90 cm by 2100. Migration from low-lying deltas — the Mekong, the Nile, Bangladesh — passes 100 million.' },
    ],
    HIGH: [
      { year: 2025, headline: 'The early signal.', body: 'Rise of 22 cm. Ice shelves crack. The phrase "marine ice-cliff instability" starts appearing in newspapers.' },
      { year: 2050, headline: 'West Antarctica destabilizes.', body: 'Rise of 70 cm. The Thwaites buttress collapses. The committee is no longer in committee.' },
      { year: 2080, headline: 'A meter and a half — and rising.', body: 'Sea level approaches 160 cm by 2100. Hundreds of cities require continuous evacuation or sea-walling. Insurance is no longer the right product.' },
    ],
  },
  precip: {
    LOW: [
      { year: 2025, headline: 'Whiplash weather.', body: 'Floods and droughts alternate. Aquifers in the Western US, India, and North Africa keep declining — but more slowly.' },
      { year: 2050, headline: 'A wetter average, drier extremes.', body: 'Global precipitation rises 4%. The extremes still hurt — but levees hold, reservoirs stay above dead pool.' },
      { year: 2080, headline: 'A new baseline.', body: 'Rainfall patterns settle into a new normal. Wetter winters in the north, drier summers in the Mediterranean. The maps get redrawn.' },
    ],
    MID: [
      { year: 2025, headline: 'Where rain used to be.', body: 'The Sahel keeps drying. The American Southwest enters a 25-year megadrought. Monsoons grow erratic.' },
      { year: 2050, headline: 'Failed harvests stack.', body: 'Multi-breadbasket failures hit once a decade. Food prices spike, plateau, spike again. Crop insurance restructures.' },
      { year: 2080, headline: 'Famine returns to the headlines.', body: 'Persistent drought across Central America, the Mediterranean rim, and the Horn of Africa drives the largest migrations of the century.' },
    ],
    HIGH: [
      { year: 2025, headline: 'A loaded atmosphere.', body: 'Warmer air holds more water — about 7% more for each degree. Extreme rainfall events arrive twice as often.' },
      { year: 2050, headline: 'Both extremes, at once.', body: 'Megafloods in Pakistan, Germany, the Carolinas. Megadroughts in Iberia and the American West. The same year, the same week.' },
      { year: 2080, headline: 'Hydrology, broken.', body: 'A third of the land surface oscillates between flood and drought every year. The phrase "100-year storm" loses any meaning.' },
    ],
  },
};

// 2100 summary numbers (illustrative — would be CMIP6 ensemble means in production).
const SUMMARY_2100 = {
  LOW:  { temp: 1.8, co2: 425, sea: 60,  precip: 4,  refugees: '30M',  energyMix: '85% clean', biodiv: '−12%', gdp: '−2%'  },
  MID:  { temp: 2.7, co2: 540, sea: 90,  precip: 7,  refugees: '120M', energyMix: '52% clean', biodiv: '−28%', gdp: '−9%'  },
  HIGH: { temp: 4.4, co2: 820, sea: 160, precip: 12, refugees: '430M', energyMix: '18% clean', biodiv: '−47%', gdp: '−23%' },
};

// Pull quotes for the "What Could Have Been?" alt cards.
const ALT_QUOTES = {
  LOW:  'Aggressive mitigation delivers a future close to the 2°C guardrail. The transition is expensive and disruptive — but the climate system stabilizes within recognizable bounds.',
  MID:  'Half-measures and compromises produce a hotter, more volatile century. Most systems adapt; many do not. Damage compounds across decades.',
  HIGH: 'Unconstrained fossil-fuel growth pushes the system into territory without modern precedent. Adaptation runs years behind the rate of change.',
};

// Historical anchors per metric — used to draw the time-series chart
// backward from 2025 to 1900 so the reader can see the "gravity" of the
// recent acceleration. Values between anchors are linearly interpolated.
// Sources are illustrative ensemble means, not exact instrumental records.
const HISTORICAL_ANCHORS = {
  // Temperature anomaly vs pre-industrial (°C)
  temp:   [[1900, -0.08], [1920, -0.16], [1940, -0.02], [1960, -0.03], [1980, 0.27], [2000, 0.60], [2025, 1.20]],
  // CO₂ concentration (ppm)
  co2:    [[1900,  296],  [1920,  304],  [1950,  311],  [1980,  338],  [2000,  370],  [2025,  423]],
  // Sea level above 1900 baseline (cm) — the existing 2025 value of 22cm
  // is interpreted as "+22 cm vs 1900", which matches instrumental estimates.
  sea:    [[1900,    0],  [1925,    4],  [1950,    7],  [1980,   13],  [2000,   17],  [2025,   22]],
  // Extreme-precip / drought combined index (% change vs 1900)
  precip: [[1900,    0],  [1950,  0.2],  [1980,  0.5],  [2000,  0.9],  [2025,  1.5]],
};

Object.assign(window, { SSP, DIALS, CHARACTERS, METRIC_BEATS, SUMMARY_2100, ALT_QUOTES, HISTORICAL_ANCHORS });
