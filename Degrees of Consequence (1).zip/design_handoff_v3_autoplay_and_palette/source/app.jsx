// ============================================================
// app.jsx — root, nav, and section orchestration
// ============================================================

const { useEffect, useRef, useState } = React;

function Nav({ chapter, progress }) {
  return (
    <nav className="nav">
      <div className="nav-brand">Degrees of <span>Consequence</span></div>
      <div className="nav-chapter">{chapter}</div>
      <div className="nav-progress" style={{ '--p': `${progress * 100}%` }} />
    </nav>
  );
}

function useScreenLabel() {
  const [label, setLabel] = useState('—');
  useEffect(() => {
    const onScroll = () => {
      const nodes = document.querySelectorAll('[data-screen-label]');
      const vh = window.innerHeight;
      let best = null;
      let bestY = -Infinity;
      nodes.forEach(n => {
        const r = n.getBoundingClientRect();
        if (r.top <= vh * 0.4 && r.top > bestY) {
          bestY = r.top;
          best = n;
        }
      });
      if (best) setLabel(best.getAttribute('data-screen-label'));
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);
  return label;
}

function useDocumentProgress() {
  const [p, setP] = useState(0);
  useEffect(() => {
    const onScroll = () => {
      const max = document.documentElement.scrollHeight - window.innerHeight;
      setP(max > 0 ? Math.max(0, Math.min(1, window.scrollY / max)) : 0);
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
    return () => {
      window.removeEventListener('scroll', onScroll);
      window.removeEventListener('resize', onScroll);
    };
  }, []);
  return p;
}

function scrollToSelector(sel) {
  const el = document.querySelector(sel);
  if (!el) return;
  const y = el.getBoundingClientRect().top + window.scrollY - 64;
  window.scrollTo({ top: y, behavior: 'smooth' });
}

function App() {
  const [selectedId, setSelectedId] = useState(null);
  const [calibrating, setCalibrating] = useState(false);
  const [timeJumpDone, setTimeJumpDone] = useState(false);
  const character = selectedId ? CHARACTERS.find(c => c.id === selectedId) : null;
  const label = useScreenLabel();
  const progress = useDocumentProgress();

  const handleContinue = () => {
    if (!character) return;
    setCalibrating(true);
  };

  const handleCalibrationDone = () => {
    setCalibrating(false);
    setTimeout(() => scrollToSelector('[data-screen-label="03 Priorities"]'), 80);
  };

  const handleTimeJumpComplete = () => {
    setTimeJumpDone(true);
    // Reveal the rest, then glide the reader into the next chapter.
    setTimeout(() => scrollToSelector('[data-screen-label="05 Metrics Intro"]'), 240);
  };

  const handleRestart = () => {
    setSelectedId(null);
    setCalibrating(false);
    setTimeJumpDone(false);
    setTimeout(() => window.scrollTo({ top: 0, behavior: 'smooth' }), 60);
  };

  return (
    <>
      <Nav chapter={label} progress={progress} />
      <Hero />
      <CharacterSelect
        selected={selectedId}
        onPick={setSelectedId}
        onContinue={handleContinue}
      />

      {character && (
        <>
          <PrioritiesScene character={character} />
          <TimeJump onComplete={handleTimeJumpComplete} />
          {timeJumpDone && (
            <>
              <MetricsIntro character={character} />
              {METRICS_DEF.map((m, i) => (
                <MetricBlock
                  key={m.id}
                  metric={m}
                  idx={i}
                  sspKey={character.ssp}
                  character={character}
                />
              ))}
              <WhatCouldHaveBeen character={character} />
              <Outro onRestart={handleRestart} />
            </>
          )}
        </>
      )}
      {calibrating && character && (
        <CalibrationOverlay character={character} onDone={handleCalibrationDone} />
      )}
    </>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
