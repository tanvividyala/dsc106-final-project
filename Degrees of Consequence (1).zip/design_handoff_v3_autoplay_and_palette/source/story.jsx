// ============================================================
// story.jsx — section components (Hero, CharacterSelect,
// Priorities, TimeJump, Metrics, WhatCouldHaveBeen, Outro)
// ============================================================

const { useEffect, useRef, useState, useMemo } = React;

// ----- HERO -----------------------------------------------------------------

function Hero({ onScrollHint }) {
  return (
    <section className="hero" data-screen-label="01 Hero">
      <div className="hero-globe-wrap"><Globe /></div>
      <div className="hero-content">
        <div className="hero-eyebrow">An interactive · 2026</div>
        <h1 className="hero-title">
          Degrees of <em>Consequence</em>
        </h1>
        <p className="hero-lede">
          The next seventy-five years will be shaped by decisions made this decade — by people you will never meet, in rooms you will never sit in. Tonight, you sit in one of those rooms. Choose carefully.
        </p>
        <div className="hero-meta">
          <span><strong>Reading</strong> · 6 minutes</span>
          <span><strong>Models</strong> · CMIP6 · SSPs</span>
          <span><strong>Issue</strong> · Vol. 01</span>
        </div>
      </div>
      <div className="hero-scroll-hint">
        <span>Scroll to begin</span>
        <div className="hero-scroll-line" />
      </div>
    </section>);

}

// ----- CHARACTER SELECT -----------------------------------------------------

function CharacterCard({ char, selected, dimmed, onPick }) {
  const [hovered, setHovered] = useState(false);
  const [quipIdx] = useCycle(char.quips, 2600, hovered || selected);
  return (
    <button
      type="button"
      className={`character-card ${selected ? 'selected' : ''} ${dimmed ? 'dimmed' : ''}`}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      onFocus={() => setHovered(true)}
      onBlur={() => setHovered(false)}
      onClick={() => onPick(char.id)}
      aria-pressed={selected}>
      
      <div className="character-portrait-wrap">
        <span className="character-tag">{char.tag}</span>
        <Portrait id={char.id} color={char.portraitColor} size="100%" />
      </div>
      <div>
        <div className="character-name">{char.name}</div>
        <div className="character-role">{char.role}</div>
      </div>
      <div className="character-quip" key={quipIdx}>{char.quips[quipIdx]}</div>
      <div className="character-quip-cycler">
        {char.quips.map((_, i) =>
        <span key={i} className={i === quipIdx ? 'on' : ''} />
        )}
      </div>
    </button>);

}

function CharacterSelect({ selected, onPick, onContinue }) {
  return (
    <section className="section character-section" data-screen-label="02 Choose">
      <div className="section-eyebrow">Chapter One · The framework</div>
      <h2 className="section-title">Three frameworks shape the next century. <br />You can only adopt one.</h2>
      <p className="section-lede">
        Each profile below represents a working theory of how climate policy gets made — the priorities it elevates, the trade-offs it accepts, the futures it tends to produce. Hover for the shape of their thinking; select one to see the seventy-five years that follow.
      </p>

      <div className="character-grid">
        {CHARACTERS.map((c) =>
        <CharacterCard
          key={c.id}
          char={c}
          selected={selected === c.id}
          dimmed={selected && selected !== c.id}
          onPick={onPick} />

        )}
      </div>

      <div className="character-cta-row">
        <div className="character-cta-hint">
          {selected ?
          <>Framework loaded · <strong>{CHARACTERS.find((c) => c.id === selected).name}</strong>.</> :
          <>Select a framework to continue.</>}
        </div>
        <button
          className="btn-primary"
          disabled={!selected}
          onClick={onContinue}>
          
          Apply this framework <ArrowRight />
        </button>
      </div>
    </section>);

}

// ----- PRIORITIES SCENE -----------------------------------------------------

function PrioritiesScene({ character }) {
  const [activeIdx, setActiveIdx] = useState(0);

  if (!character) return null;

  const ssp = SSP[character.ssp];
  const stageCount = DIALS.length;
  const currentDial = DIALS[activeIdx];
  const thought = character.thoughts[currentDial.id];

  return (
    <section className="priorities-wrap" data-screen-label="03 Priorities">
      <div className="priorities-inner">
        {/* Left: thinker monologue */}
        <div className="thinker">
          <div className="thinker-card">
            <div className="thinker-avatar"><Portrait id={character.id} color={character.portraitColor} size="100%" /></div>
            <div>
              <div className="thinker-name">{character.name}</div>
              <div className="thinker-role">{character.role}</div>
            </div>
          </div>

          <div className="thought-bubble" key={activeIdx}>
            <div className="thought-eyebrow">
              Priority {String(activeIdx + 1).padStart(2, '0')} of {String(stageCount).padStart(2, '0')}
            </div>
            <h3 className="thought-title fade-in">{currentDial.label}</h3>
            <div className="thought-definition fade-in">{currentDial.definition}</div>
            <div className="thought-divider" />
            <div className="thought-text fade-in">{thought}</div>
            <div className="thought-progress" role="tablist" aria-label="Priorities">
              {DIALS.map((d, i) =>
              <button
                key={d.id}
                type="button"
                role="tab"
                aria-selected={i === activeIdx}
                aria-label={`See priority: ${d.label}`}
                className={`thought-progress-dot ${i === activeIdx ? 'active' : ''}`}
                onClick={() => setActiveIdx(i)} />
              )}
            </div>
            <div className="thought-meta">Click any knob to inspect how this framework treats it.</div>
          </div>
        </div>

        {/* Right: control panel */}
        <div className="panel">
          <div className="panel-header">
            <div className="panel-title">Policy console</div>
            <div className="panel-readout">
              <span className="panel-readout-dot" />
              Six knobs · click any
            </div>
          </div>

          <div className="panel-grid">
            {DIALS.map((d, i) =>
            <button
              key={d.id}
              type="button"
              className={`dial-button ${i === activeIdx ? 'active' : ''}`}
              onClick={() => setActiveIdx(i)}
              aria-pressed={i === activeIdx}
              aria-label={`Inspect ${d.label}`}>
              <Dial
                value={character.dials[d.id]}
                label={d.label}
                subtitle={d.subtitle}
                active={i === activeIdx}
                inverted={d.inverted} />
            </button>
            )}
          </div>

          <div className="panel-footer">
            <span>Projected pathway</span>
            <span className="pathway">
              {ssp.code} · {ssp.shortName} · +{ssp.warming}°C
            </span>
          </div>
        </div>
      </div>
    </section>);

}

// ----- CALIBRATION OVERLAY --------------------------------------------------
// A transitional intermezzo: dials wobble chaotically, then snap into the
// chosen framework's settings, then the overlay clears to the priorities scene.

function CalibrationOverlay({ character, onDone }) {
  // phases: wobble → settle → exit
  const [phase, setPhase] = useState('wobble');
  const [values, setValues] = useState(() =>
    Object.fromEntries(DIALS.map((d) => [d.id, Math.round(Math.random() * 100)]))
  );

  useEffect(() => {
    const WOBBLE_MS = 1800;
    const HOLD_MS = 1200;
    const EXIT_MS = 700;

    // Chaotic value churn during wobble.
    const churn = setInterval(() => {
      setValues(Object.fromEntries(DIALS.map((d) => [d.id, Math.round(Math.random() * 100)])));
    }, 140);

    const t1 = setTimeout(() => {
      clearInterval(churn);
      setPhase('settle');
      setValues(Object.fromEntries(DIALS.map((d) => [d.id, character.dials[d.id]])));
    }, WOBBLE_MS);

    const t2 = setTimeout(() => setPhase('exit'), WOBBLE_MS + HOLD_MS);
    const t3 = setTimeout(() => onDone && onDone(), WOBBLE_MS + HOLD_MS + EXIT_MS);

    return () => {
      clearInterval(churn);
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
    };
  }, [character, onDone]);

  const ssp = SSP[character.ssp];
  const captions = {
    wobble: 'Calibrating · framework parameters',
    settle: `${character.name} · settings locked`,
    exit:   'Entering the policy console',
  };

  return (
    <div className={`calibration-overlay phase-${phase}`} role="status" aria-live="polite">
      <div className="calibration-inner">
        <div className="calibration-eyebrow">
          <span className="calibration-dot" />
          {captions[phase]}
        </div>

        <div className={`panel calibration-panel calibration-${phase}`}>
          <div className="panel-header">
            <div className="panel-title">Policy console</div>
            <div className="panel-readout">
              <span className="panel-readout-dot" />
              {phase === 'wobble' ? 'Live · adjusting' : 'Live · holding'}
            </div>
          </div>

          <div className="panel-grid">
            {DIALS.map((d) =>
            <Dial
              key={d.id}
              value={values[d.id] ?? 0}
              label={d.label}
              subtitle={d.subtitle}
              active={phase === 'wobble'}
              wobbling={phase === 'wobble'}
              inverted={d.inverted} />
            )}
          </div>

          <div className="panel-footer">
            <span>Projected pathway</span>
            <span className="pathway">
              {phase === 'wobble' ? '— — —' : `${ssp.code} · ${ssp.shortName} · +${ssp.warming}°C`}
            </span>
          </div>
        </div>

        <div className="calibration-caption">
          {phase === 'wobble' && 'Six knobs, no fixed answer — searching the space.'}
          {phase === 'settle' && 'Settings locked in. Inspect each knob on the next screen.'}
          {phase === 'exit' && 'Continuing.'}
        </div>
      </div>
    </div>);

}

// ----- TIME JUMP ------------------------------------------------------------

function TimeJump({ onComplete }) {
  const wrapRef = useRef(null);
  const [p, setP] = useState(0);
  const [started, setStarted] = useState(false);
  const completedRef = useRef(false);

  // Start the auto-run once the section scrolls into view.
  useEffect(() => {
    if (started) return;
    const check = () => {
      const el = wrapRef.current;
      if (!el) return;
      const r = el.getBoundingClientRect();
      const vh = window.innerHeight;
      if (r.top < vh * 0.6 && r.bottom > vh * 0.4) {
        setStarted(true);
      }
    };
    check();
    window.addEventListener('scroll', check, { passive: true });
    window.addEventListener('resize', check);
    return () => {
      window.removeEventListener('scroll', check);
      window.removeEventListener('resize', check);
    };
  }, [started]);

  // Drive p from 0 → 1 over DURATION_MS, then notify parent.
  useEffect(() => {
    if (!started) return;
    const DURATION_MS = 8500;
    const start = performance.now();
    let raf;
    const tick = (now) => {
      const elapsed = now - start;
      const next = Math.min(1, elapsed / DURATION_MS);
      setP(next);
      if (next < 1) {
        raf = requestAnimationFrame(tick);
      } else if (!completedRef.current) {
        completedRef.current = true;
        // Small breathing pause so the final beat reads before unlocking.
        setTimeout(() => onComplete && onComplete(), 900);
      }
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [started, onComplete]);

  // 2025 → 2100 across full progress. Hold last 15% on 2100.
  const t = clamp(p / 0.85, 0, 1);
  const eased = 1 - Math.pow(1 - t, 1.6);
  const year = Math.round(2025 + 75 * eased);

  const lines = [
  { from: 0.00, to: 0.18, text: 'The room empties. The decisions begin to settle.' },
  { from: 0.18, to: 0.38, text: 'A decade passes. Then another.' },
  { from: 0.38, to: 0.62, text: 'Children born during the meeting are now writing the headlines.' },
  { from: 0.62, to: 0.84, text: 'The atmosphere keeps a perfect ledger.' },
  { from: 0.84, to: 1.01, text: 'The future arrives. On schedule.' }];

  const activeLine = lines.find((l) => p >= l.from && p < l.to) || lines[lines.length - 1];

  return (
    <section className="timejump-wrap" data-screen-label="04 Time Jump" ref={wrapRef}>
      <div className="timejump-sticky">
        <div className="timejump-bg">
          <svg viewBox="0 0 600 600">
            {/* concentric year rings */}
            {[80, 140, 200, 260, 320].map((r, i) =>
            <circle key={i} cx="300" cy="300" r={r} fill="none" stroke="#fbf6e9" strokeWidth="1" opacity={0.3 - i * 0.04} />
            )}
            {/* radial tick marks (1 per year) */}
            {Array.from({ length: 76 }).map((_, i) => {
              const a = (-90 + i / 76 * 360) * Math.PI / 180;
              const r1 = 320 + (i % 5 === 0 ? 6 : 2);
              const r2 = 340;
              const x1 = 300 + Math.cos(a) * r1;
              const y1 = 300 + Math.sin(a) * r1;
              const x2 = 300 + Math.cos(a) * r2;
              const y2 = 300 + Math.sin(a) * r2;
              const reached = 2025 + i <= year;
              return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2}
              stroke={reached ? '#f1a97a' : '#fbf6e9'}
              strokeWidth={reached ? 1.5 : 1}
              opacity={reached ? 0.7 : 0.18} />;
            })}
            {/* current position pointer */}
            {(() => {
              const a = (-90 + (year - 2025) / 75 * 360) * Math.PI / 180;
              const x = 300 + Math.cos(a) * 360;
              const y = 300 + Math.sin(a) * 360;
              return (
                <g>
                  <line x1="300" y1="300" x2={x} y2={y} stroke="#f1a97a" strokeWidth="1.5" opacity="0.6" />
                  <circle cx={x} cy={y} r="6" fill="#f1a97a" />
                </g>);

            })()}
          </svg>
        </div>

        <div className="timejump-inner">
          <div className="timejump-eyebrow">Chapter Two · The future arrives</div>
          <div className="timejump-year">{year}</div>
          <div className="timejump-line fade-in" key={activeLine.text}>{activeLine.text}</div>
          <div className="timejump-ticker">
            <span>← 2025</span>
            <span style={{ color: 'var(--apricot-500)' }}>Now · {year}</span>
            <span>2100 →</span>
          </div>
          <div className="timejump-progress" aria-hidden="true">
            <div className="timejump-progress-fill" style={{ width: `${Math.round(p * 100)}%` }} />
          </div>
        </div>
      </div>
    </section>);

}

// ----- METRIC BLOCK ---------------------------------------------------------

function pickBeat(beats, year) {
  let chosen = beats[0];
  for (const b of beats) if (year >= b.year) chosen = b;
  return chosen;
}

function MetricBlock({ metric, idx, sspKey, character }) {
  const wrapRef = useRef(null);
  const p = useScrollProgress(wrapRef);
  const year = Math.round(2025 + p * 75);
  const curve = useMemo(() => getMetricCurve(metric.id, sspKey), [metric.id, sspKey]);
  const historical = useMemo(() => getMetricHistorical(metric.id), [metric.id]);
  const value = curve[clamp(year - 2025, 0, 75)].val;
  const beats = METRIC_BEATS[metric.id][sspKey];
  const beat = pickBeat(beats, year);
  const Viz = METRIC_VIZ[metric.id];

  return (
    <section className="metric-wrap" data-screen-label={`05${String.fromCharCode(65 + idx)} ${metric.title}`} ref={wrapRef}>
      <div className={`metric-sticky theme-${metric.id}`}>
        <div className="metric-row">
          <div>
            <div className="metric-eyebrow">
              <span className="num">{String(idx + 1).padStart(2, '0')}</span>
              <span>{metric.title}</span>
            </div>
            <div className="metric-year">{year}</div>
            <h3 className="metric-headline fade-in" key={beat.headline}>{beat.headline}</h3>
            <p className="metric-body fade-in" key={beat.body}>{beat.body}</p>
          </div>
          <div className="metric-viz">
            <Viz year={year} value={value} />
          </div>
        </div>

        <div className="metric-mini">
          <div className="metric-mini-head">
            <div className="metric-mini-label">
              {metric.title}<br />
              <span className="metric-mini-range">1900 \u2192 2100</span>
            </div>
            <div className="metric-mini-current">
              {metric.format(value)}
              <div className="metric-mini-currentlabel">in {year}</div>
            </div>
          </div>
          <TimeSeriesChart
            historical={historical}
            projected={curve}
            currentYear={year}
            accent="var(--metric-accent)"
            muted="currentColor"
            xTicks={[1900, 1950, 2000, 2025, 2050, 2075, 2100]}
            yTicks={metric.yTicks}
            formatY={metric.formatY}
            height={200}
          />
        </div>
      </div>
    </section>);

}

const METRICS_DEF = [
  { id: 'temp',   title: 'Temperature',
    format:   (v) => `+${v.toFixed(1)}\u00b0C`,
    formatY:  (v) => `${v.toFixed(1).replace(/\.0$/, '')}\u00b0`,
    yTicks:   [0, 1, 2, 3, 4] },
  { id: 'co2',    title: 'CO\u2082',
    format:   (v) => `${Math.round(v)} ppm`,
    formatY:  (v) => `${v}`,
    yTicks:   [300, 400, 500, 600, 700, 800] },
  { id: 'sea',    title: 'Sea level',
    format:   (v) => `+${Math.round(v)} cm`,
    formatY:  (v) => `${v}`,
    yTicks:   [0, 40, 80, 120, 160] },
  { id: 'precip', title: 'Rainfall',
    format:   (v) => `+${v.toFixed(1)}%`,
    formatY:  (v) => `${v}%`,
    yTicks:   [0, 4, 8, 12] }
];


// ----- METRICS INTRO --------------------------------------------------------

function MetricsIntro({ character }) {
  const ssp = SSP[character.ssp];
  return (
    <section className="metrics-intro" data-screen-label="05 Metrics Intro">
      <div className="metrics-intro-eyebrow">Chapter Three · The numbers</div>
      <h2 className="metrics-intro-title">
        Here is the world<br />you chose.
      </h2>
      <p className="metrics-intro-sub">
        Four measurements, one path, seventy-five years. Scroll each panel to watch the dial move from 2025 to 2100.
      </p>
      <div className="metrics-intro-pathway">
        <span className="dot" style={{ background: ssp.color }} />
        <span>{ssp.code} · {ssp.name} · +{ssp.warming}°C by 2100</span>
      </div>
    </section>);

}

// ----- WHAT COULD HAVE BEEN -------------------------------------------------

function AltCard({ altChar, yourChar }) {
  const ssp = SSP[altChar.ssp];
  const yourSsp = SSP[yourChar.ssp];
  const sum = SUMMARY_2100[altChar.ssp];
  const yourSum = SUMMARY_2100[yourChar.ssp];

  const delta = (a, b, units, better) => {
    if (a === b) return 'same as yours';
    const diff = a - b;
    const sign = diff > 0 ? '+' : '';
    const cls = (better === 'lower' ? diff < 0 : diff > 0) ? 'delta-better' : 'delta-worse';
    return <span className={cls}>{sign}{units === 'pct' ? `${diff}%` : `${diff}${units}`} vs you</span>;
  };

  return (
    <article className="alt-card">
      <header className="alt-card-head">
        <div className="alt-card-avatar"><Portrait id={altChar.id} color={altChar.portraitColor} size="100%" /></div>
        <div>
          <div className="alt-card-name">{altChar.name}</div>
          <div className="alt-card-pathway">
            <span className="swatch" style={{ background: ssp.color }} />
            {ssp.code} · {ssp.shortName} · +{ssp.warming}°C
          </div>
        </div>
      </header>

      <blockquote className="alt-card-headline">{ALT_QUOTES[altChar.ssp]}</blockquote>

      <div className="alt-card-metrics">
        <div className="alt-card-metric">
          <div className="alt-card-metric-label">Warming</div>
          <div className="alt-card-metric-value">+{sum.temp}°</div>
          <div className="alt-card-metric-delta">{delta(sum.temp, yourSum.temp, '°', 'lower')}</div>
        </div>
        <div className="alt-card-metric">
          <div className="alt-card-metric-label">Sea level</div>
          <div className="alt-card-metric-value">+{sum.sea}cm</div>
          <div className="alt-card-metric-delta">{delta(sum.sea, yourSum.sea, 'cm', 'lower')}</div>
        </div>
        <div className="alt-card-metric">
          <div className="alt-card-metric-label">Refugees</div>
          <div className="alt-card-metric-value">{sum.refugees}</div>
          <div className="alt-card-metric-delta">{sum.refugees === yourSum.refugees ? 'same' : ''}</div>
        </div>
        <div className="alt-card-metric">
          <div className="alt-card-metric-label">GDP impact</div>
          <div className="alt-card-metric-value">{sum.gdp}</div>
          <div className="alt-card-metric-delta">{sum.gdp === yourSum.gdp ? 'same' : ''}</div>
        </div>
      </div>

      <p className="alt-card-quote">
        Under this framework, the same atmospheric ledger produces a different set of numbers. The values above are end-of-century projections.
      </p>
    </article>);

}

function WhatCouldHaveBeen({ character }) {
  const others = CHARACTERS.filter((c) => c.id !== character.id);
  return (
    <section className="what-section" data-screen-label="06 What Could Have Been">
      <div className="what-head">
        <h2 className="what-title">
          What <em>could</em> have been?
        </h2>
        <p className="what-sub">
          The two frameworks not selected pursue different priorities, and the atmosphere — which keeps a perfect record — responds accordingly. Below are the worlds those frameworks tend to produce.
        </p>
      </div>
      <div className="what-grid">
        {others.map((c) => <AltCard key={c.id} altChar={c} yourChar={character} />)}
      </div>
    </section>);

}

// ----- OUTRO ----------------------------------------------------------------

function Outro({ onRestart }) {
  return (
    <section className="outro" data-screen-label="07 Outro">
      <div className="outro-inner">
        <div>
          <div className="hero-eyebrow" style={{ color: 'var(--apricot-500)' }}>Coda</div>
          <h2 className="outro-title">
            The frameworks in this article are <em>simplified</em>. The ones shaping policy are not.
          </h2>
          <p className="outro-body">
            Three frameworks, six dials, one atmosphere — a deliberately reduced model. Real climate policy comprises thousands of decisions across hundreds of institutions, each one less tidy than this. The dials, however, are accurate. So are the consequences.
          </p>
          <button className="btn-primary" onClick={onRestart}>
            <RestartIcon /> Try a different framework
          </button>
        </div>
        <div className="outro-credits">
          <div><strong>Modeling</strong> — CMIP6 ensemble means, illustrative</div>
          <div><strong>Pathways</strong> — IPCC AR6 · SSP1-2.6 · SSP2-4.5 · SSP5-8.5</div>
          <div><strong>Design</strong> — Tanvi Vidyala, 2026</div>
          <div><strong>Built for</strong> — anyone weighing whether any of this is worth doing</div>
        </div>
      </div>
    </section>);

}

Object.assign(window, {
  Hero, CharacterSelect, PrioritiesScene, CalibrationOverlay, TimeJump,
  MetricsIntro, MetricBlock, METRICS_DEF,
  WhatCouldHaveBeen, Outro
});